package com.example.dailyquotewidget

import android.app.Activity
import android.app.DatePickerDialog
import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.CalendarView
import android.widget.DatePicker
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import java.time.LocalDate

class MainActivity : AppCompatActivity() {
    private lateinit var tvPreview: TextView
    private lateinit var tvDday: TextView
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val quotes = mutableListOf<String>()
    private val createExport = 101
    private val openImport = 102

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        tvPreview = findViewById(R.id.tvPreview)
        tvDday = findViewById(R.id.tvDday)
        listView = findViewById(R.id.lvQuotes)
        quotes.addAll(QuoteStorage.getQuotes(this))
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, quotes)
        listView.adapter = adapter

        findViewById<android.widget.Button>(R.id.btnAdd).setOnClickListener { showQuoteDialog() }
        findViewById<android.widget.Button>(R.id.btnBulkAdd).setOnClickListener { showBulkQuoteDialog() }
        findViewById<android.widget.Button>(R.id.btnShuffle).setOnClickListener { refreshPreview(true); QuoteWidgetProvider.updateAllWidgets(this, true) }
        findViewById<android.widget.Button>(R.id.btnColors).setOnClickListener { showColorDialog() }
        findViewById<android.widget.Button>(R.id.btnDday).setOnClickListener { showDdayDialog() }
        findViewById<android.widget.Button>(R.id.btnExport).setOnClickListener { exportQuotes() }
        findViewById<android.widget.Button>(R.id.btnImport).setOnClickListener { importQuotes() }
        listView.setOnItemClickListener { _, _, pos, _ -> showQuoteDialog(pos) }
        listView.setOnItemLongClickListener { _, _, pos, _ -> confirmDelete(pos); true }
        findViewById<CalendarView>(R.id.calendarView).setOnDateChangeListener { _, y, m, d ->
            Toast.makeText(this, "${y}년 ${m + 1}월 ${d}일", Toast.LENGTH_SHORT).show()
        }
        refreshPreview(false)
        refreshDday()
    }

    private fun exportQuotes() {
        val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
            type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE); putExtra(Intent.EXTRA_TITLE, "daily_quotes_backup.json")
        }
        startActivityForResult(intent, createExport)
    }
    private fun importQuotes() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { type = "application/json"; addCategory(Intent.CATEGORY_OPENABLE) }
        startActivityForResult(intent, openImport)
    }
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != Activity.RESULT_OK || data?.data == null) return
        try {
            val uri = data.data!!
            if (requestCode == createExport) {
                contentResolver.openOutputStream(uri)?.use { it.write(QuoteStorage.exportQuotes(this).toByteArray(Charsets.UTF_8)) }
                Toast.makeText(this, "문장 백업 저장 완료", Toast.LENGTH_SHORT).show()
            } else if (requestCode == openImport) {
                contentResolver.openInputStream(uri)?.bufferedReader(Charsets.UTF_8)?.use {
                    val count = QuoteStorage.importQuotes(this, it.readText())
                    quotes.clear(); quotes.addAll(QuoteStorage.getQuotes(this)); persistAndRefresh()
                    Toast.makeText(this, "${count}개 문장 불러옴", Toast.LENGTH_SHORT).show()
                }
            }
        } catch (e: Exception) { Toast.makeText(this, "파일 처리 오류: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showQuoteDialog(editPosition: Int? = null) {
        val editing = editPosition != null
        val input = EditText(this).apply {
            setText(if (editing) quotes[editPosition!!] else "")
            hint = "문장 하나를 입력하세요"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
            minLines = 3; maxLines = 6; setSelection(text.length)
        }
        val dialog = AlertDialog.Builder(this).setTitle(if (editing) "문장 편집" else "새 문장 추가")
            .setView(input).setNegativeButton("취소", null).setPositiveButton(if (editing) "저장" else "추가", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val sentence = input.text.toString().trim().replace(Regex("\\s*\\n\\s*"), " ")
                if (sentence.isBlank()) { input.error = "문장을 입력하세요"; return@setOnClickListener }
                if (editing) quotes[editPosition!!] = sentence else quotes.add(sentence)
                persistAndRefresh(); dialog.dismiss()
            }
        }
        dialog.show()
    }
    private fun showBulkQuoteDialog() {
        val input = EditText(this).apply { hint = "문장마다 한 줄씩 입력"; inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE; minLines = 6; maxLines = 12; setPadding(36, 24, 36, 24) }
        val dialog = AlertDialog.Builder(this).setTitle("여러 문장 한꺼번에 추가").setView(input).setNegativeButton("취소", null).setPositiveButton("모두 추가", null).create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val items = input.text.toString().lines().map { it.trim().replace(Regex("\\s+"), " ") }.filter { it.isNotBlank() }
                if (items.isEmpty()) { input.error = "문장을 입력하세요"; return@setOnClickListener }
                quotes.addAll(items); persistAndRefresh(); dialog.dismiss(); Toast.makeText(this, "${items.size}개 추가", Toast.LENGTH_SHORT).show()
            }
        }
        dialog.show()
    }
    private fun confirmDelete(position: Int) {
        AlertDialog.Builder(this).setTitle("문장 삭제").setMessage("이 문장을 삭제할까요?\n\n${quotes[position]}")
            .setNegativeButton("취소", null).setPositiveButton("삭제") { _, _ ->
                quotes.removeAt(position); if (quotes.isEmpty()) quotes.add("오늘 집중한 1시간이 내일의 여유를 만든다."); persistAndRefresh()
            }.show()
    }
    private fun persistAndRefresh() { QuoteStorage.saveQuotes(this, quotes); adapter.notifyDataSetChanged(); refreshPreview(false); QuoteWidgetProvider.updateAllWidgets(this, false) }
    private fun refreshPreview(force: Boolean) { tvPreview.text = QuoteStorage.getDailyQuote(this, force); tvPreview.setBackgroundColor(QuoteStorage.getWidgetColor(this)); tvPreview.setTextColor(QuoteStorage.getTextColor(this)) }
    private fun refreshDday() { tvDday.text = QuoteStorage.ddayText(this) }
    private fun showColorDialog() {
        val labels = QuoteStorage.colorPresets.map { it.first }
        AlertDialog.Builder(this).setTitle("위젯 배경색 선택").setItems(labels.toTypedArray()) { _, which ->
            val bg = QuoteStorage.colorPresets[which].second
            val fg = if (bg == 0xFFEDE4D2.toInt()) Color.BLACK else Color.WHITE
            QuoteStorage.setColors(this, bg, fg); refreshPreview(false); QuoteWidgetProvider.updateAllWidgets(this, false)
        }.setNegativeButton("취소", null).show()
    }
    private fun showDdayDialog() {
        val container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24, 8, 24, 8) }
        val label = EditText(this).apply { hint = "목표 이름 (시험, 여행 등)"; setText(QuoteStorage.getDdayLabel(this@MainActivity)) }
        val datePicker = DatePicker(this)
        val existing = QuoteStorage.getDdayDate(this)?.let { LocalDate.parse(it) } ?: LocalDate.now()
        datePicker.updateDate(existing.year, existing.monthValue - 1, existing.dayOfMonth)
        container.addView(label); container.addView(datePicker)
        AlertDialog.Builder(this).setTitle("D-Day 설정").setView(container).setNegativeButton("취소", null)
            .setPositiveButton("저장") { _, _ ->
                val date = LocalDate.of(datePicker.year, datePicker.month + 1, datePicker.dayOfMonth).toString()
                QuoteStorage.setDday(this, date, label.text.toString().trim().ifBlank { "목표일" }); refreshDday(); QuoteWidgetProvider.updateAllWidgets(this, false)
            }.setNeutralButton("D-Day 삭제") { _, _ -> QuoteStorage.setDday(this, null, "목표일"); refreshDday(); QuoteWidgetProvider.updateAllWidgets(this, false) }.show()
    }
}
