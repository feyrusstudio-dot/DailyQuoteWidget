package com.example.dailyquotewidget

import android.os.Bundle
import android.text.InputType
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private lateinit var tvPreview: TextView
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private val quotes = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPreview = findViewById(R.id.tvPreview)
        listView = findViewById(R.id.lvQuotes)
        val btnAdd = findViewById<android.widget.Button>(R.id.btnAdd)
        val btnShuffle = findViewById<android.widget.Button>(R.id.btnShuffle)

        quotes.clear()
        quotes.addAll(QuoteStorage.getQuotes(this))
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, quotes)
        listView.adapter = adapter
        refreshPreview(false)


        // Add each quote through its own dialog window.
        btnAdd.setOnClickListener { showQuoteDialog() }

        btnShuffle.setOnClickListener {
            refreshPreview(true)
            QuoteWidgetProvider.updateAllWidgets(this, true)
        }


        // Tap a quote to edit it.
        listView.setOnItemClickListener { _, _, position, _ -> showQuoteDialog(position) }


        // Long-press a quote to delete it.
        listView.setOnItemLongClickListener { _, _, position, _ ->
            confirmDelete(position)
            true
        }
    }


    private fun showQuoteDialog(editPosition: Int? = null) {
        val isEditing = editPosition != null
        val input = EditText(this).apply {
            setText(if (isEditing) quotes[editPosition!!] else "")
            hint = "문장 하나를 입력하세요"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
            minLines = 3
            maxLines = 6
            setSelection(text.length)
        }

        AlertDialog.Builder(this)
            .setTitle(if (isEditing) "문장 편집" else "새 문장 추가")
            .setView(input)
            .setNegativeButton("취소", null)
            .setPositiveButton(if (isEditing) "저장" else "추가", null)
            .create()
            .also { dialog ->
                dialog.setOnShowListener {
                    dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                        val text = input.text.toString().trim().replace(Regex("\\s*\\n\\s*"), " ")
                        if (text.isBlank()) {
                            input.error = "문장을 입력하세요."
                            return@setOnClickListener
                        }
                        if (isEditing) quotes[editPosition!!] = text else quotes.add(text)
                        persistAndRefresh()
                        dialog.dismiss()
                        Toast.makeText(this, if (isEditing) "문장을 수정했습니다." else "문장을 추가했습니다.", Toast.LENGTH_SHORT).show()
                    }
                }
                dialog.show()
            }
    }


    private fun confirmDelete(position: Int) {
        AlertDialog.Builder(this)
            .setTitle("문장 삭제")
            .setMessage("이 문장을 삭제할까요?\n\n${quotes[position]}")
            .setNegativeButton("취소", null)
            .setPositiveButton("삭제") { _, _ ->
                quotes.removeAt(position)
                if (quotes.isEmpty()) {
                    quotes.add("오늘 집중한 1시간이 내일의 여유를 만든다.")
                }
                persistAndRefresh()
                Toast.makeText(this, "문장을 삭제했습니다.", Toast.LENGTH_SHORT).show()
            }
            .show()
    }


    private fun persistAndRefresh() {
        QuoteStorage.saveQuotes(this, quotes)
        adapter.notifyDataSetChanged()
        refreshPreview(false)
        QuoteWidgetProvider.updateAllWidgets(this, false)
    }


    private fun refreshPreview(forceNew: Boolean) {
        tvPreview.text = QuoteStorage.getDailyQuote(this, forceNew)
    }
}
