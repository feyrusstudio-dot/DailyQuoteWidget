package com.example.dailyquotewidget

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate
import kotlin.random.Random

object QuoteStorage {
    private const val PREFS_NAME = "daily_quote_prefs"
    private const val KEY_QUOTES = "quotes_json"
    private const val KEY_CURRENT_QUOTE = "current_quote"
    private const val KEY_LAST_DATE = "last_date"

    private val defaultQuotes = listOf(
        "오늘 집중한 1시간이 내일의 여유를 만든다.",
        "완벽함보다 꾸준함이 결국 결과를 바꾼다.",
        "지금 해야 할 가장 작은 일 하나부터 시작하자."
    )

    fun getQuotes(context: Context): MutableList<String> {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val raw = prefs.getString(KEY_QUOTES, null) ?: return defaultQuotes.toMutableList()
        val list = mutableListOf<String>()
        val arr = JSONArray(raw)
        for (i in 0 until arr.length()) {
            val item = arr.getString(i).trim()
            if (item.isNotEmpty()) list.add(item)
        }
        return if (list.isEmpty()) defaultQuotes.toMutableList() else list
    }

    fun saveQuotes(context: Context, quotes: List<String>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val arr = JSONArray()
        quotes.map { it.trim() }.filter { it.isNotEmpty() }.forEach { arr.put(it) }
        prefs.edit().putString(KEY_QUOTES, arr.toString()).apply()
    }

    fun getDailyQuote(context: Context, forceNew: Boolean = false): String {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val today = LocalDate.now().toString()
        val savedDate = prefs.getString(KEY_LAST_DATE, "")
        val savedQuote = prefs.getString(KEY_CURRENT_QUOTE, null)
        val quotes = getQuotes(context)

        if (!forceNew && savedDate == today && !savedQuote.isNullOrBlank() && quotes.contains(savedQuote)) {
            return savedQuote
        }

        val candidates = if (quotes.size > 1 && savedQuote != null) {
            quotes.filter { it != savedQuote }
        } else {
            quotes
        }
        val picked = candidates[Random.nextInt(candidates.size)]
        prefs.edit()
            .putString(KEY_LAST_DATE, today)
            .putString(KEY_CURRENT_QUOTE, picked)
            .apply()
        return picked
    }
}
