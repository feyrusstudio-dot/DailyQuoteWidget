package com.example.dailyquotewidget

import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.ListView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var tvPreview: TextView
    private lateinit var etQuoteInput: EditText
    private lateinit var listView: ListView
    private lateinit var adapter: ArrayAdapter<String>
    private var quotes = mutableListOf<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvPreview = findViewById(R.id.tvPreview)
        etQuoteInput = findViewById(R.id.etQuoteInput)
        listView = findViewById(R.id.lvQuotes)
        val btnAdd: Button = findViewById(R.id.btnAdd)
        val btnShuffle: Button = findViewById(R.id.btnShuffle)

        quotes = QuoteStorage.getQuotes(this)
        adapter = ArrayAdapter(this, android.R.layout.simple_list_item_1, quotes)
        listView.adapter = adapter

        refreshPreview(forceNew = false)

        btnAdd.setOnClickListener {
            val raw = etQuoteInput.text.toString()
            val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }
            if (lines.isEmpty()) {
                Toast.makeText(this, "문장을 입력하세요.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            quotes.addAll(lines)
            QuoteStorage.saveQuotes(this, quotes)
            adapter.notifyDataSetChanged()
            etQuoteInput.text.clear()
            QuoteWidgetProvider.updateAllWidgets(this, forceNew = false)
            refreshPreview(forceNew = false)
            Toast.makeText(this, "${lines.size}개 문장이 저장되었습니다.", Toast.LENGTH_SHORT).show()
        }

        btnShuffle.setOnClickListener {
            refreshPreview(forceNew = true)
            QuoteWidgetProvider.updateAllWidgets(this, forceNew = true)
        }

        listView.setOnItemLongClickListener { _, _, position, _ ->
            if (quotes.size <= 1) {
                Toast.makeText(this, "최소 1개의 문장은 유지해야 합니다.", Toast.LENGTH_SHORT).show()
                return@setOnItemLongClickListener true
            }
            quotes.removeAt(position)
            QuoteStorage.saveQuotes(this, quotes)
            adapter.notifyDataSetChanged()
            refreshPreview(forceNew = false)
            QuoteWidgetProvider.updateAllWidgets(this, forceNew = false)
            Toast.makeText(this, "문장이 삭제되었습니다.", Toast.LENGTH_SHORT).show()
            true
        }
    }

    private fun refreshPreview(forceNew: Boolean) {
        tvPreview.text = QuoteStorage.getDailyQuote(this, forceNew)
    }
}
