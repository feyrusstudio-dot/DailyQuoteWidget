package com.example.dailyquotewidget

import android.content.Context
import org.json.JSONArray
import java.time.LocalDate
import java.time.temporal.ChronoUnit
import kotlin.random.Random

object QuoteStorage {
    private const val PREFS_NAME = "daily_quote_prefs"
    private const val KEY_QUOTES = "quotes_json"
    private const val KEY_CURRENT_QUOTE = "current_quote"
    private const val KEY_LAST_DATE = "last_date"
    const val KEY_WIDGET_COLOR = "widget_color"
    const val KEY_TEXT_COLOR = "widget_text_color"
    const val KEY_DDAY_DATE = "dday_date"
    const val KEY_DDAY_LABEL = "dday_label"

    val colorPresets = listOf(
        "차콜" to 0xFF263238.toInt(), "네이비" to 0xFF14213D.toInt(), "블랙" to 0xFF111111.toInt(),
        "그린" to 0xFF245B45.toInt(), "버건디" to 0xFF6D2332.toInt(), "퍼플" to 0xFF49345E.toInt(),
        "블루" to 0xFF22577A.toInt(), "크림" to 0xFFEDE4D2.toInt()
    )
    fun prefs(context: Context) = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    fun getWidgetColor(context: Context) = prefs(context).getInt(KEY_WIDGET_COLOR, 0xFF263238.toInt())
    fun getTextColor(context: Context) = prefs(context).getInt(KEY_TEXT_COLOR, 0xFFFFFFFF.toInt())
    fun setColors(context: Context, bg: Int, text: Int) { prefs(context).edit().putInt(KEY_WIDGET_COLOR,bg).putInt(KEY_TEXT_COLOR,text).apply() }
    fun getDdayDate(context: Context) = prefs(context).getString(KEY_DDAY_DATE, null)
    fun getDdayLabel(context: Context) = prefs(context).getString(KEY_DDAY_LABEL, "목표일") ?: "목표일"
    fun setDday(context: Context, date: String?, label: String) { prefs(context).edit().putString(KEY_DDAY_DATE,date).putString(KEY_DDAY_LABEL,label).apply() }
    fun ddayText(context: Context): String {
        val raw=getDdayDate(context) ?: return "D-Day 설정 안 됨"
        return try {
            val days=ChronoUnit.DAYS.between(LocalDate.now(),LocalDate.parse(raw))
            val prefix=if(days>0) "D-$days" else if(days==0L) "D-Day" else "D+${-days}"
            "$prefix · ${getDdayLabel(context)}"
        } catch (_: Exception) { "D-Day 설정 안 됨" }
    }
    private val defaultQuotes = listOf("오늘 집중한 1시간이 내일의 여유를 만든다.","완벽함보다 꾸준함이 결국 결과를 바꾼다.","지금 해야 할 가장 작은 일 하나부터 시작하자.")
    fun getQuotes(context: Context): MutableList<String> {
        val raw=prefs(context).getString(KEY_QUOTES,null) ?: return defaultQuotes.toMutableList()
        val arr=JSONArray(raw); val list=mutableListOf<String>()
        for(i in 0 until arr.length()) { val s=arr.optString(i).trim(); if(s.isNotEmpty()) list.add(s) }
        return if(list.isEmpty()) defaultQuotes.toMutableList() else list
    }
    fun saveQuotes(context: Context, quotes: List<String>) {
        val arr=JSONArray(); quotes.map{it.trim()}.filter{it.isNotEmpty()}.forEach{arr.put(it)}
        prefs(context).edit().putString(KEY_QUOTES,arr.toString()).apply()
    }
    fun exportQuotes(context: Context): String { val arr=JSONArray(); getQuotes(context).forEach{arr.put(it)}; return arr.toString(2) }
    fun importQuotes(context: Context, json: String): Int {
        val arr=JSONArray(json); val parsed=mutableListOf<String>()
        for(i in 0 until arr.length()) { val s=arr.optString(i).trim(); if(s.isNotEmpty()) parsed.add(s) }
        if(parsed.isNotEmpty()) saveQuotes(context,parsed)
        return parsed.size
    }
    fun getDailyQuote(context: Context, forceNew: Boolean = false): String {
        val p=prefs(context); val today=LocalDate.now().toString(); val savedDate=p.getString(KEY_LAST_DATE,""); val savedQuote=p.getString(KEY_CURRENT_QUOTE,null); val quotes=getQuotes(context)
        if(!forceNew && savedDate==today && !savedQuote.isNullOrBlank() && quotes.contains(savedQuote)) return savedQuote
        val candidates=if(quotes.size>1 && savedQuote!=null) quotes.filter{it!=savedQuote} else quotes
        val picked=candidates[Random.nextInt(candidates.size)]
        p.edit().putString(KEY_LAST_DATE,today).putString(KEY_CURRENT_QUOTE,picked).apply(); return picked
    }
}
