package com.example.dailyquotewidget

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.widget.RemoteViews

class QuoteWidgetProvider : AppWidgetProvider() {
 override fun onUpdate(context:Context, manager:AppWidgetManager, ids:IntArray){ ids.forEach{updateAppWidget(context,manager,it,false)} }
 override fun onReceive(context:Context,intent:Intent){super.onReceive(context,intent);if(intent.action==ACTION_REFRESH)updateAllWidgets(context,true)}
 companion object {
  const val ACTION_REFRESH="com.example.dailyquotewidget.ACTION_REFRESH"
  fun updateAllWidgets(context:Context,forceNew:Boolean){val m=AppWidgetManager.getInstance(context);m.getAppWidgetIds(ComponentName(context,QuoteWidgetProvider::class.java)).forEach{updateAppWidget(context,m,it,forceNew)}}
  fun updateAppWidget(context:Context,m:AppWidgetManager,id:Int,forceNew:Boolean){val views=RemoteViews(context.packageName,R.layout.widget_quote);views.setTextViewText(R.id.tvWidgetQuote,QuoteStorage.getDailyQuote(context,forceNew));views.setTextViewText(R.id.tvWidgetDday,QuoteStorage.ddayText(context));views.setInt(R.id.widgetRoot,"setBackgroundColor",QuoteStorage.getWidgetColor(context));views.setTextColor(R.id.tvWidgetQuote,QuoteStorage.getTextColor(context));views.setTextColor(R.id.tvWidgetDday,QuoteStorage.getTextColor(context));val intent=Intent(context,QuoteWidgetProvider::class.java).apply{action=ACTION_REFRESH};val pending=PendingIntent.getBroadcast(context,0,intent,PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE);views.setOnClickPendingIntent(R.id.widgetRoot,pending);m.updateAppWidget(id,views)}
 }
}
